/**
 * File level comment as the first thing in a file (GOOD).
 * @license Copyright 2009 SomeThirdParty.
 */
/** // WRONG_BLANK_LINE_COUNT
 * Comment block that is not the first thing in a file (BAD).
 * @license Copyright 2009 SomeThirdParty.
 */

/** // WRONG_BLANK_LINE_COUNT
 * Top level comment with a single line above it (BAD).
 * @license Copyright 2009 SomeThirdParty.
 */
